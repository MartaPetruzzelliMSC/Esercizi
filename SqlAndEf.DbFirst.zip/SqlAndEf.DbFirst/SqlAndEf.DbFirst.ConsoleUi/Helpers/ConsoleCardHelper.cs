﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.ConsoleUi.Helpers;

public static class ConsoleCardHelper
{
    public static void PrintCustomerCard(CustomerDto customer)
    {
        Console.WriteLine($"+-- Customer #{customer.CustomerId}");
        Console.WriteLine($"|  Company     : {customer.CompanyName}");
        Console.WriteLine($"|  Email       : {customer.Email}");
        Console.WriteLine($"|  Phone       : {customer.Phone ?? "N/A"}");
        Console.WriteLine($"|  Address     : {customer.Address ?? "N/A"}");
        Console.WriteLine($"|  Created     : {customer.CreatedDate:yyyy-MM-dd HH:mm}");
        Console.WriteLine($"|  Bookings    : {customer.TotalBookings}");
        Console.WriteLine($"+{new string('-', 60)}");
        Console.WriteLine();
    }

    public static void PrintVesselCard(VesselDto vessel)
    {
        Console.WriteLine($"+-- Vessel #{vessel.VesselId}");
        Console.WriteLine($"|  Name        : {vessel.VesselName}");
        Console.WriteLine($"|  Capacity    : {vessel.Capacity:N0} tons");
        Console.WriteLine($"|  Year Built  : {vessel.YearBuilt.ToString() ?? "N/A"}");
        Console.WriteLine($"|  Current Load: {vessel.CurrentLoad:N2} tons");
        Console.WriteLine($"|  Available   : {vessel.AvailableCapacity:N2} tons ({(vessel.AvailableCapacity / vessel.Capacity * 100):F1}%)");
        Console.WriteLine($"|  Shipments   : {vessel.TotalShipments}");
        Console.WriteLine($"+{new string('-', 60)}");
        Console.WriteLine();
    }

    public static void PrintBookingCard(BookingDto booking)
    {
        Console.WriteLine($"+-- Booking #{booking.BookingId}");
        Console.WriteLine($"|  Customer    : {booking.CustomerName}");
        Console.WriteLine($"|  Route       : {booking.DeparturePort} → {booking.ArrivalPort}");
        Console.WriteLine($"|  Date        : {booking.BookingDate:yyyy-MM-dd HH:mm}");
        Console.WriteLine($"|  Status      : {booking.Status}");
        Console.WriteLine($"|  Has Shipment: {(booking.HasShipment ? "Yes" : "No")}");
        if (!string.IsNullOrEmpty(booking.Notes))
            Console.WriteLine($"|  Notes       : {booking.Notes}");
        Console.WriteLine($"+{new string('-', 60)}");
        Console.WriteLine();
    }

    public static void PrintShipmentCard(ShipmentDto shipment)
    {
        Console.WriteLine($"+-- Shipment #{shipment.ShipmentId}");
        Console.WriteLine($"|  Customer    : {shipment.CustomerName}");
        Console.WriteLine($"|  Vessel      : {shipment.VesselName}");
        Console.WriteLine($"|  Departure   : {shipment.DepartureDate?.ToString("yyyy-MM-dd HH:mm") ?? "Not started"}");
        Console.WriteLine($"|  Arrival     : {shipment.ArrivalDate?.ToString("yyyy-MM-dd HH:mm") ?? "In transit"}");
        if (shipment.TripDuration.HasValue)
            Console.WriteLine($"|  Duration    : {shipment.TripDuration} days");
        Console.WriteLine($"|  Cargo       : {shipment.CargoWeight:N2} tons");
        Console.WriteLine($"|  Cost        : €{shipment.ShippingCost:N2}");
        Console.WriteLine($"+{new string('-', 60)}");
        Console.WriteLine();
    }
}
