﻿namespace SqlAndEf.DbFirst.ConsoleUi.Helpers;

static class ConsoleErrorHelper
{
    public static void Print(string message)
    {
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Error.WriteLine();
        Console.Error.WriteLine($"### {message} ###");
        Console.ResetColor();
    }

    public static void Print(Exception ex)
    {
        Console.Error.Write("MESSAGE: ");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Error.WriteLine(ex.Message);
        Console.ResetColor();
        Console.Error.Write("STACKTRACE: ");
        Console.ForegroundColor = ConsoleColor.Red;
        Console.Error.WriteLine(ex.StackTrace);
        Console.ResetColor();
    }
}
