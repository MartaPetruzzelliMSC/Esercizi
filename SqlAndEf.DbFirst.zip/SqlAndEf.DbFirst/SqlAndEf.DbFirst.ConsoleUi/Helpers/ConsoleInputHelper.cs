﻿namespace SqlAndEf.DbFirst.ConsoleUi.Helpers;

public static class ConsoleInputHelper
{
    public static string ReadString(string prompt, bool required = true)
    {
        while (true)
        {
            Console.Write($"{prompt}: ");
            var input = Console.ReadLine()?.Trim();

            if (!required || !string.IsNullOrWhiteSpace(input))
                return input ?? string.Empty;

            ConsoleErrorHelper.Print("This field is required.");
        }
    }

    public static int ReadInt(string prompt, int? min = null, int? max = null)
    {
        while (true)
        {
            Console.Write($"{prompt}: ");
            if (int.TryParse(Console.ReadLine(), out var value))
            {
                if (min.HasValue && value < min.Value)
                {
                    ConsoleErrorHelper.Print($"Value must be at least {min.Value}.");
                    continue;
                }

                if (max.HasValue && value > max.Value)
                {
                    ConsoleErrorHelper.Print($"Value must be at most {max.Value}.");
                    continue;
                }

                return value;
            }

            ConsoleErrorHelper.Print("Please enter a valid number.");
        }
    }

    public static decimal ReadDecimal(string prompt, decimal? min = null, decimal? max = null)
    {
        while (true)
        {
            Console.Write($"{prompt}: ");
            if (decimal.TryParse(Console.ReadLine(), out var value))
            {
                if (min.HasValue && value < min.Value)
                {
                    ConsoleErrorHelper.Print($"Value must be at least {min.Value}.");
                    continue;
                }

                if (max.HasValue && value > max.Value)
                {
                    ConsoleErrorHelper.Print($"Value must be at most {max.Value}.");
                    continue;
                }

                return value;
            }

            ConsoleErrorHelper.Print("Please enter a valid decimal number.");
        }
    }

    public static DateTime ReadDateTime(string prompt)
    {
        while (true)
        {
            Console.Write($"{prompt} (yyyy-MM-dd HH:mm): ");
            if (DateTime.TryParseExact(
                Console.ReadLine(),
                "yyyy-MM-dd HH:mm",
                null,
                System.Globalization.DateTimeStyles.None,
                out var value))
            {
                return value;
            }

            ConsoleErrorHelper.Print("Please enter a valid date in format yyyy-MM-dd HH:mm.");
        }
    }

    public static bool Confirm(string message)
    {
        Console.Write($"{message} (y/n): ");
        var response = Console.ReadLine()?.Trim().ToLower();
        return response == "y" || response == "yes";
    }
}
