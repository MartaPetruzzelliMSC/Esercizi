﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class ShowAllVesselsCommand : ICommand
{
    private readonly IVesselService _vesselService;

    public string DisplayName => "Show All Vessels";
    public string Shortcut => "SAV";

    public ShowAllVesselsCommand(IVesselService vesselService)
    {
        _vesselService = vesselService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("ALL VESSELS");

        var vessels = await _vesselService.GetAllVesselsAsync();

        if (vessels.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No active vessels in the fleet.");
            return;
        }

        ConsoleTableHelper.PrintCount(vessels.Count, "vessel");

        foreach (var vessel in vessels)
        {
            ConsoleCardHelper.PrintVesselCard(vessel);
        }
    }
}