﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

class ShowAllCustomersCommand : ICommand
{
    private readonly ICustomerService _customerService;

    public string DisplayName => "Show All Customers";
    public string Shortcut => "SAC";

    public ShowAllCustomersCommand(ICustomerService customerService)
    {
        _customerService = customerService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("ALL CUSTOMERS");

        var customers = await _customerService.GetAllCustomersAsync();

        if (customers.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No customers in the database.");
            return;
        }

        ConsoleTableHelper.PrintCount(customers.Count, "customer");

        foreach (var customer in customers)
        {
            ConsoleCardHelper.PrintCustomerCard(customer);
        }
    }
}