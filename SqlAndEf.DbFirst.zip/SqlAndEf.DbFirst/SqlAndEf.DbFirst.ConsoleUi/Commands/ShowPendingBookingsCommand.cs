﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class ShowPendingBookingsCommand : ICommand
{
    private readonly IBookingService _bookingService;

    public string DisplayName => "Show Pending Bookings";
    public string Shortcut => "SPB";

    public ShowPendingBookingsCommand(IBookingService bookingService)
    {
        _bookingService = bookingService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("PENDING BOOKINGS");

        var bookings = await _bookingService.GetPendingBookingsAsync();

        if (bookings.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No pending bookings.");
            return;
        }

        ConsoleTableHelper.PrintCount(bookings.Count, "pending booking");

        foreach (var booking in bookings)
        {
            ConsoleCardHelper.PrintBookingCard(booking);
        }
    }
}
