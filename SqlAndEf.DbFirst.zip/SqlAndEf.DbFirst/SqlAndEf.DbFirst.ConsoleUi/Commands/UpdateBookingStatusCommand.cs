﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.BusinessLogic.Services.Impl;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using SqlAndEf.DbFirst.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Azure.Core.HttpHeader;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands
{
    public class UpdateBookingStatusCommand : ICommand
    {
        public string DisplayName => "Update Booking Status";

        public string Shortcut => "UBS";

        private readonly IBookingService _bookingService;

        public UpdateBookingStatusCommand(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        public async Task Execute()
        {
            ConsoleTableHelper.PrintHeader("UPDATE BOOKING STATUS");

            var bookings = await _bookingService.GetPendingBookingsAsync();

            if (bookings.Count == 0)
            {
                ConsoleTableHelper.PrintEmptyResult("No pending bookings.");
                return;
            }

            ConsoleTableHelper.PrintCount(bookings.Count, "pending booking");

            foreach (var b in bookings)
            {
                ConsoleCardHelper.PrintBookingCard(b);
            }

            var bookingId = ConsoleInputHelper.ReadInt("Booking ID", min: 1);
            if (!bookings.Any(b => b.BookingId == bookingId))
            {
                ConsoleErrorHelper.Print("Invalid booking ID or booking not available.");
                return;
            }

            var booking = await _bookingService.GetBookingByIdAsync(bookingId);

            var newStatus = ConsoleInputHelper.ReadString("Update Status", required: true);
            if(!newStatus.Equals("Confirmed") && newStatus != "Cancelled")
            {
                Console.WriteLine("Invalid answer");
                return;
            }

            try
            {
                await _bookingService.UpdateBookingStatusAsync(bookingId, newStatus);

                ConsoleTableHelper.PrintSuccess($"Booking #{bookingId} status updated succesfully!");
                ConsoleCardHelper.PrintBookingCard(await _bookingService.GetBookingByIdAsync(bookingId));
            }
            catch (InvalidOperationException ex)
            {
                ConsoleErrorHelper.Print($"Validation failed: {ex.Message}");
            }
            catch (Exception ex)
            {
                ConsoleErrorHelper.Print($"Failed to create shipment: {ex.Message}");
            }
        }
    }
}
