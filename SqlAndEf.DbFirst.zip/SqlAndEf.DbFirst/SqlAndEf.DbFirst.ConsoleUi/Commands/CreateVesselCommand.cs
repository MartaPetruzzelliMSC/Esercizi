﻿using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.BusinessLogic.Services.Impl;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands
{
    public class CreateVesselCommand : ICommand
    {
        private readonly IVesselService _vesselService;
        public string DisplayName => "Create New Vessel";
        public string Shortcut => "CNV";

        public CreateVesselCommand(IVesselService vesselService)
        {
            _vesselService = vesselService;
        }

        public async Task Execute()
        {
            ConsoleTableHelper.PrintHeader("ADD NEW VEESSEL");

            var vesselName = ConsoleInputHelper.ReadString("Vessel Name", required: true);
            var yearBuilt = ConsoleInputHelper.ReadInt("Year Built", min: 0, max: DateTime.Now.Year);
            var capacity = ConsoleInputHelper.ReadInt("Capacity", min: 0);

            try
            {
                // TODO: Add customer
                UpsertVesselDto vessel = new()
                {
                    VesselName = vesselName,
                    YearBuilt = yearBuilt,
                    Capacity = capacity
                };

                var id = await _vesselService.CreateVesselAsync(vessel);


                ConsoleTableHelper.PrintSuccess($"Customer '{vessel.VesselName}' added successfully with ID #{id}");
                ConsoleCardHelper.PrintVesselCard(await _vesselService.GetVesselByIdAsync(id));
            }
            catch (Exception ex)
            {
                ConsoleErrorHelper.Print($"Failed to add customer: {ex.Message}");
            }
        }
    }
}
