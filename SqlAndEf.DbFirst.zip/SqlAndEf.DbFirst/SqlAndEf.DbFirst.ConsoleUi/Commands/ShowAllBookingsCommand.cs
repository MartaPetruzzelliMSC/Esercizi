﻿using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.ConsoleUi.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.ConsoleUi.Commands;

public class ShowAllBookingsCommand : ICommand
{
    private readonly IBookingService _bookingService;

    public string DisplayName => "Show All Bookings";
    public string Shortcut => "SAB";

    public ShowAllBookingsCommand(IBookingService bookingService)
    {
        _bookingService = bookingService;
    }

    public async Task Execute()
    {
        ConsoleTableHelper.PrintHeader("ALL BOOKINGS");

        var bookings = await _bookingService.GetAllBookingsAsync();

        if (bookings.Count == 0)
        {
            ConsoleTableHelper.PrintEmptyResult("No bookings found.");
            return;
        }

        ConsoleTableHelper.PrintCount(bookings.Count, "booking");

        foreach (var booking in bookings)
        {
            ConsoleCardHelper.PrintBookingCard(booking);
        }
    }
}
