﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SqlAndEf.DbFirst.BusinessLogic.Services;
using SqlAndEf.DbFirst.BusinessLogic.Services.Impl;
using SqlAndEf.DbFirst.ConsoleUi.Commands;
using SqlAndEf.DbFirst.DataAccess.Context;

namespace SqlAndEf.DbFirst.ConsoleUi;

internal class Program
{
    static async Task Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // Register DbContext
                string connectionString = "Server=HQAPEW1C966-AAJ;Database=ShippingCompanyDb;User Id=sa;Password=SQL2019;TrustServerCertificate=True;";
                services.AddDbContext<ShippingCompanyDbContext>(options => options.UseSqlServer(connectionString));
                // Register Application Services
                services.AddScoped<ICustomerService, CustomerService>();
                services.AddScoped<IVesselService, VesselService>();
                services.AddScoped<IBookingService, BookingService>();
                services.AddScoped<IShipmentService, ShipmentService>();

                // Register Commands for Console App
                services.AddSingleton<ICommand, AddCustomerCommand>();
                services.AddSingleton<ICommand, CompleteShipmentCommand>();
                services.AddSingleton<ICommand, CreateBookingCommand>();
                services.AddSingleton<ICommand, CreateShipmentCommand>();
                services.AddSingleton<ICommand, ShowAllBookingsCommand>();
                services.AddSingleton<ICommand, ShowAllCustomersCommand>();
                services.AddSingleton<ICommand, ShowAllShipmentsCommand>();
                services.AddSingleton<ICommand, ShowAllVesselsCommand>();
                services.AddSingleton<ICommand, ShowPendingBookingsCommand>();
                services.AddSingleton<ICommand, CreateVesselCommand>();
                services.AddSingleton<ICommand, UpdateBookingStatusCommand>();

                // Register main App
                services.AddSingleton<App>();
            })
            .Build();

        // Execute application
        var app = host.Services.GetRequiredService<App>();
        await app.RunAsync();
    }
}
