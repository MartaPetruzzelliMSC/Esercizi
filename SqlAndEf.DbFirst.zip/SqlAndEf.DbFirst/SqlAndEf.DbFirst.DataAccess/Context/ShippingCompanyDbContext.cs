﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.DataAccess.Context;

public partial class ShippingCompanyDbContext : DbContext
{
    public ShippingCompanyDbContext()
    {
    }

    public ShippingCompanyDbContext(DbContextOptions<ShippingCompanyDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Booking> Bookings { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<Shipment> Shipments { get; set; }

    public virtual DbSet<Vessel> Vessels { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=HQAPEW1C966-AAJ;Database=ShippingCompanyDb;User Id=sa;Password=SQL2019;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Booking>(entity =>
        {
            entity.HasKey(e => e.BookingId).HasName("PK__Bookings__73951AED7D589D69");

            entity.Property(e => e.ArrivalPort)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.BookingDate).HasDefaultValueSql("(sysutcdatetime())");
            entity.Property(e => e.DeparturePort)
                .IsRequired()
                .HasMaxLength(100);
            entity.Property(e => e.Notes).HasMaxLength(500);
            entity.Property(e => e.Status)
                .HasMaxLength(20)
                .HasDefaultValue("Pending");

            entity.HasOne(d => d.Customer).WithMany(p => p.Bookings)
                .HasForeignKey(d => d.CustomerId)
                .HasConstraintName("FK_Bookings_Customers");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.CustomerId).HasName("PK__Customer__A4AE64D8C650A76E");

            entity.Property(e => e.Address)
                .IsRequired()
                .HasMaxLength(255);
            entity.Property(e => e.CompanyName)
                .IsRequired()
                .HasMaxLength(255);
            entity.Property(e => e.CreateDate).HasDefaultValueSql("(sysutcdatetime())");
            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(255);
            entity.Property(e => e.Phone)
                .IsRequired()
                .HasMaxLength(255);
        });

        modelBuilder.Entity<Shipment>(entity =>
        {
            entity.HasKey(e => e.ShipmentId).HasName("PK__Shipment__5CAD37ED09EBFF19");

            entity.HasIndex(e => e.BookingId, "UQ__Shipment__73951AEC42674F43").IsUnique();

            entity.Property(e => e.CargoWeigth).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ShippingCost).HasColumnType("decimal(10, 2)");

            entity.HasOne(d => d.Booking).WithOne(p => p.Shipment)
                .HasForeignKey<Shipment>(d => d.BookingId)
                .HasConstraintName("FK_Shipments_Bookings");

            entity.HasOne(d => d.Vessel).WithMany(p => p.Shipments)
                .HasForeignKey(d => d.VesselId)
                .HasConstraintName("FK_Shipments_Vessels");
        });

        modelBuilder.Entity<Vessel>(entity =>
        {
            entity.HasKey(e => e.VesselId).HasName("PK__Vessels__9148DE8363D64D2C");

            entity.Property(e => e.VesselName)
                .IsRequired()
                .HasMaxLength(255);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
