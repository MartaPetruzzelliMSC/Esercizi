﻿using System;
using System.Collections.Generic;

namespace SqlAndEf.DbFirst.DataAccess.Models;

public partial class Shipment
{
    public int ShipmentId { get; set; }

    public int BookingId { get; set; }

    public int VesselId { get; set; }

    public DateTime? DepartureDate { get; set; }

    public DateTime? ArrivalDate { get; set; }

    public decimal CargoWeigth { get; set; }

    public decimal ShippingCost { get; set; }

    public virtual Booking Booking { get; set; }

    public virtual Vessel Vessel { get; set; }
}
