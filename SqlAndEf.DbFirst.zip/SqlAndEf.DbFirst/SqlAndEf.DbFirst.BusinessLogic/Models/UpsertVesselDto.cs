﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Models
{
    public class UpsertVesselDto
    {
        public string VesselName { get; set; }
        public int Capacity { get; set; }
        public int YearBuilt { get; set; }
    }
}
