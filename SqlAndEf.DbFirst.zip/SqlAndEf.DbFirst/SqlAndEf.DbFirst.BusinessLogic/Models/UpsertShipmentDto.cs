﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Models
{
    public class UpsertShipmentDto
    {
        public int BookingId { get; set; }
        public int VesselId { get; set; }
        public DateTime? DepartureDate { get; set; }
        public decimal CargoWeight { get; set; }
        public decimal? ShippingCost { get; set; }
    }
}
