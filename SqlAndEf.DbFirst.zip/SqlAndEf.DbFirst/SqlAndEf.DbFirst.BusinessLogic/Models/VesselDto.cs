﻿namespace SqlAndEf.DbFirst.BusinessLogic.Models;

public class VesselDto
{
    public int VesselId { get; set; }
    public string VesselName { get; set; }
    public int Capacity { get; set; }
    public int YearBuilt { get; set; }
    public int TotalShipments { get; set; }
    public decimal CurrentLoad { get; set; }
    public decimal AvailableCapacity => Capacity - CurrentLoad;
}
