﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Models
{
    public class UpsertBookingDto
    {
        public int CustomerId { get; set; }
        public string DeparturePort { get; set; }
        public string ArrivalPort { get; set; }
        public string Status { get; set; } = "Pending";
        public string? Notes { get; set; }
    }
}
