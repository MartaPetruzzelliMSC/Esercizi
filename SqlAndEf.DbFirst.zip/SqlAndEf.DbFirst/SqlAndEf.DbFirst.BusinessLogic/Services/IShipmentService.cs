﻿
using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface IShipmentService
{
    Task<List<ShipmentDto>> GetAllShipmentsAsync();
    Task<ShipmentDto> GetShipmentByIdAsync(int id);
    Task<int> CreateShipmentAsync(UpsertShipmentDto dto);
    Task CompleteShipmentAsync(int id, DateTime arrivalDate);
}
