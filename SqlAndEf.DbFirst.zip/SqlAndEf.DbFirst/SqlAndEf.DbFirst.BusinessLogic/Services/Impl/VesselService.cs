﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Context;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class VesselService : IVesselService
{
    private readonly ShippingCompanyDbContext _context;

    public VesselService(ShippingCompanyDbContext context)
    {
        _context = context;
    }

    public async Task<List<VesselDto>> GetAllVesselsAsync()
    {
        var vessels = _context.Vessels.AsNoTracking()
            .Select(x => new VesselDto
            {
                VesselId = x.VesselId,
                VesselName = x.VesselName,
                Capacity = x.Capacity,
                YearBuilt = x.YearBuilt,
                TotalShipments = x.Shipments.Count,
                CurrentLoad = x.Shipments.Where(x => x.Booking.Status == "Pending").Sum(x => x.CargoWeigth)
            });

        return await vessels.ToListAsync();
    }

    public async Task<VesselDto> GetVesselByIdAsync(int vesselId)
    {
        var vessel = await _context.Vessels.AsNoTracking()
            .Select(x => new VesselDto
            {
                VesselId = x.VesselId,
                VesselName = x.VesselName,
                Capacity = x.Capacity,
                YearBuilt = x.YearBuilt,
                TotalShipments = x.Shipments.Count,
                CurrentLoad = x.Shipments.Where(x => x.Booking.Status == "Pending").Sum(x => x.CargoWeigth)
            }).FirstOrDefaultAsync(x => x.VesselId == vesselId);

        return vessel;
    }

    public async Task<int> CreateVesselAsync(UpsertVesselDto dto)
    {
        var vessel = _context.Vessels.Add(new Vessel
        {
            VesselName = dto.VesselName,
            Capacity = dto.Capacity,
            YearBuilt = dto.YearBuilt
        }).Entity;

        await _context.SaveChangesAsync();

        return vessel.VesselId;
    }
}
