﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Context;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class CustomerService : ICustomerService
{
    private readonly ShippingCompanyDbContext _context;

    public CustomerService(ShippingCompanyDbContext context)
    {
        _context = context;
    }

    public async Task<List<CustomerDto>> GetAllCustomersAsync()
    {
        var customers = _context.Customers.AsNoTracking()
            .Select(x => new CustomerDto
        {
            CustomerId = x.CustomerId,
            CompanyName = x.CompanyName,
            CreatedDate = x.CreateDate,
            Email = x.Email,
            Phone = x.Phone,
            Address = x.Address,
            TotalBookings = x.Bookings.Count()
        });

        return await customers.ToListAsync();
    }

    public async Task<int> CreateCustomerAsync(UpsertCustomerDto dto)
    {
        var c = _context.Customers.Add(new Customer
        {
            CompanyName = dto.CompanyName,
            Email = dto.Email,
            Phone = dto.Phone,
            Address = dto.Address
        }).Entity;

        await _context.SaveChangesAsync();

        return c.CustomerId;
    }

    public async Task<CustomerDto> GetCustomerByIdAsync(int id)
    {
        var customer = await _context.Customers.AsNoTracking()
            .Select(x => new CustomerDto
                {
                    CustomerId = x.CustomerId,
                    CompanyName = x.CompanyName,
                    CreatedDate = x.CreateDate,
                    Email = x.Email,
                    Phone = x.Phone,
                    Address = x.Address,
                    TotalBookings = x.Bookings.Count()
                }).FirstOrDefaultAsync(x => x.CustomerId == id);

        return customer;
    }

    public async Task UpdateCustomerAsync(int id, UpsertCustomerDto dto)
    {
        var c = await _context.Customers.FindAsync(id) ?? throw new InvalidOperationException();

        c.CompanyName = dto.CompanyName;
        c.Address = dto.Address;
        c.Phone = dto.Phone;
        c.Email = dto.Email;

        _context.Entry(c).State = EntityState.Modified;

        await _context.SaveChangesAsync();
    }

    public async Task DeleteCustomerAsync(int id)
    {
        var c = await _context.Customers.FindAsync(id) ?? throw new InvalidOperationException();

        _context.Remove(c);
        _context.Entry(c).State = EntityState.Deleted;

        await _context.SaveChangesAsync();
    }
}
