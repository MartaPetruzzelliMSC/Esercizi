﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Context;
using SqlAndEf.DbFirst.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class ShipmentService : IShipmentService
{
    private readonly ShippingCompanyDbContext _context;

    public ShipmentService(ShippingCompanyDbContext context)
    {
        _context = context;
    }


    public async Task<List<ShipmentDto>> GetAllShipmentsAsync()
    {
        var shipments = _context.Shipments.AsNoTracking()
            .Select(x => new ShipmentDto
            {
                ShipmentId = x.ShipmentId,
                BookingId = x.BookingId,
                CustomerName = x.Booking.Customer.CompanyName,
                VesselId = x.VesselId,
                VesselName = x.Vessel.VesselName,
                DepartureDate = x.DepartureDate,
                ArrivalDate = x.ArrivalDate,
                CargoWeight = x.CargoWeigth,
                ShippingCost = x.ShippingCost
            });

        return await shipments.ToListAsync();
    }
    public async Task<int> CreateShipmentAsync(UpsertShipmentDto dto)
    {
        var s = _context.Shipments.Add(new Shipment
        {
            BookingId = dto.BookingId,
            VesselId = dto.VesselId,
            DepartureDate = dto.DepartureDate,
            CargoWeigth = dto.CargoWeight,
            ShippingCost = dto.ShippingCost ?? 0.0m
        }).Entity;

        await _context.SaveChangesAsync();

        return s.ShipmentId;
    }

    public async Task<ShipmentDto> GetShipmentByIdAsync(int id)
    {
        var shipments = await _context.Shipments.AsNoTracking()
            .Select(x => new ShipmentDto
            {
                ShipmentId = x.ShipmentId,
                BookingId = x.BookingId,
                CustomerName = x.Booking.Customer.CompanyName,
                VesselId = x.VesselId,
                VesselName = x.Vessel.VesselName,
                DepartureDate = x.DepartureDate,
                ArrivalDate = x.ArrivalDate,
                CargoWeight = x.CargoWeigth,
                ShippingCost = x.ShippingCost
            }).FirstOrDefaultAsync(x => x.ShipmentId == id);

        return shipments;
    }

    public async Task CompleteShipmentAsync(int id, DateTime arrivalDate)
    {
        var s = await _context.Shipments.FindAsync(id) ?? throw new InvalidOperationException();

        s.ArrivalDate = arrivalDate;
        _context.Entry(s).State = EntityState.Modified;

        await _context.SaveChangesAsync();
    }
}
