﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.DbFirst.BusinessLogic.Models;
using SqlAndEf.DbFirst.DataAccess.Context;
using SqlAndEf.DbFirst.DataAccess.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services.Impl;

public class BookingService : IBookingService
{
    private readonly ShippingCompanyDbContext _context;

    public BookingService(ShippingCompanyDbContext context)
    {
        _context = context;
    }

    public async Task<int> CreateBookingAsync(UpsertBookingDto dto)
    {
        var b = _context.Bookings.Add(new Booking
        {
            CustomerId = dto.CustomerId,
            DeparturePort = dto.DeparturePort,
            ArrivalPort = dto.ArrivalPort,
            Notes = dto.Notes,
        }).Entity;

        await _context.SaveChangesAsync();

        return b.BookingId;
    }

    public async Task<List<BookingDto>> GetAllBookingsAsync()
    {
        var bookings = _context.Bookings.Select(x => new BookingDto
        {
            BookingId = x.BookingId,
            CustomerId = x.CustomerId,
            CustomerName = x.Customer.CompanyName,
            BookingDate = x.BookingDate,
            DeparturePort = x.DeparturePort,
            ArrivalPort = x.ArrivalPort,
            Status = x.Status,
            Notes = x.Notes,
            HasShipment = x.Shipment == null ? false : true
        });

        return await bookings.ToListAsync();
    }

    public async Task<BookingDto> GetBookingByIdAsync(int id)
    {
        var bookings = await _context.Bookings.Select(x => new BookingDto
        {
            BookingId = x.BookingId,
            CustomerId = x.CustomerId,
            CustomerName = x.Customer.CompanyName,
            BookingDate = x.BookingDate,
            DeparturePort = x.DeparturePort,
            ArrivalPort = x.ArrivalPort,
            Status = x.Status,
            Notes = x.Notes,
            HasShipment = x.Shipment == null ? false : true
        }).FirstOrDefaultAsync(x => x.BookingId == id);

        return bookings;
    }

    public async Task<List<BookingDto>> GetPendingBookingsAsync()
    {
        var bookings = _context.Bookings.Select(x => new BookingDto
        {
            BookingId = x.BookingId,
            CustomerId = x.CustomerId,
            CustomerName = x.Customer.CompanyName,
            BookingDate = x.BookingDate,
            DeparturePort = x.DeparturePort,
            ArrivalPort = x.ArrivalPort,
            Status = x.Status,
            Notes = x.Notes,
            HasShipment = x.Shipment == null ? false : true
        }).Where(x => x.Status.Equals("Pending"));

        return await bookings.ToListAsync();
    }

    public async Task UpdateBookingAsync(int id, UpsertBookingDto dto)
    {
        var b = await _context.Bookings.FindAsync(id) ?? throw new InvalidOperationException();

        b.CustomerId = dto.CustomerId;
        b.Status = dto.Status;
        b.DeparturePort = dto.DeparturePort;
        b.ArrivalPort = dto.ArrivalPort;
        b.Notes = dto.Notes;

        _context.Entry(b).State = EntityState.Modified;

        await _context.SaveChangesAsync();
    }

    public async Task UpdateBookingStatusAsync(int id, string status)
    {
        var b = await _context.Bookings.FindAsync(id) ?? throw new InvalidOperationException();

        b.Status = status;
        _context.Entry(b).State = EntityState.Modified;

        await _context.SaveChangesAsync();
    }
}
