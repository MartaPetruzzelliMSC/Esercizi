﻿using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface ICustomerService
{
    Task<List<CustomerDto>> GetAllCustomersAsync();
    Task<CustomerDto> GetCustomerByIdAsync(int id);
    Task<int> CreateCustomerAsync(UpsertCustomerDto dto);
    Task UpdateCustomerAsync(int id, UpsertCustomerDto dto);
    Task DeleteCustomerAsync(int id);
}
