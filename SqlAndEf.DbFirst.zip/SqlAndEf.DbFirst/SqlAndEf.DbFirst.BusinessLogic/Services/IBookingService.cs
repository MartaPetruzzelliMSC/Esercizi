﻿
using SqlAndEf.DbFirst.BusinessLogic.Models;

namespace SqlAndEf.DbFirst.BusinessLogic.Services;

public interface IBookingService
{
    Task<List<BookingDto>> GetAllBookingsAsync();
    Task<List<BookingDto>> GetPendingBookingsAsync();
    Task<BookingDto> GetBookingByIdAsync(int id);
    Task<int> CreateBookingAsync(UpsertBookingDto dto);
    Task UpdateBookingAsync(int id, UpsertBookingDto dto);
    Task UpdateBookingStatusAsync(int id, string status);
}
