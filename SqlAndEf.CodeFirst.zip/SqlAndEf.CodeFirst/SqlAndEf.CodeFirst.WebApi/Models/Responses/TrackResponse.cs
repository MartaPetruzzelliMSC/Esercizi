namespace SqlAndEf.CodeFirst.WebApi.Models.Responses;

public class TrackResponse
{
    public int TrackId { get; set; }
    public string Title { get; set; }
    public int? AlbumId { get; set; }
    public string AlbumTitle { get; set; }
    public int GenreId { get; set; }
    public string GenreName { get; set; }
    public int DurationSeconds { get; set; }
    public List<string> Artists { get; set; }
}
