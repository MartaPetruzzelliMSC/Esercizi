namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class CreateTrackAuthorRequest
{
    public int TrackId { get; set; }
    public int ArtistId { get; set; }
}
