namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class UpdateArtistRequest
{
    public string Name { get; set; }
    public string Country { get; set; }
}
