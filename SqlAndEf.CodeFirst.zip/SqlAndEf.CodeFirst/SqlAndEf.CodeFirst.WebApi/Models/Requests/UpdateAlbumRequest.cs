namespace SqlAndEf.CodeFirst.WebApi.Models.Requests;

public class UpdateAlbumRequest
{
    public string Title { get; set; }
    public int ReleaseYear { get; set; }
}
