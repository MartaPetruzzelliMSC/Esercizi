using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/artists/{artistId}/tracks")]
public class ArtistTracksController : ControllerBase
{
    private readonly ITrackService _trackService;
    private readonly ILogger<ArtistTracksController> _logger;

    public ArtistTracksController(ITrackService trackService, ILogger<ArtistTracksController> logger)
    {
        _trackService = trackService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<TrackResponse>>> GetTracksByArtist(int artistId)
    {
        var tracks = await _trackService.GetTracksByArtistAsync(artistId);
        var response = tracks.Select(t => new TrackResponse
        {
            TrackId = t.TrackId,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t.AlbumTitle,
            GenreId = t.GenreId,
            GenreName = t.GenreName,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists
        }).ToList();

        return Ok(response);
    }
}
