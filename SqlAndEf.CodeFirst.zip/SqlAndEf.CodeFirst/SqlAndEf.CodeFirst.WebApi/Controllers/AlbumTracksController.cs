using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/albums/{albumId}/tracks")]
public class AlbumTracksController : ControllerBase
{
    private readonly ITrackService _trackService;
    private readonly ILogger<AlbumTracksController> _logger;

    public AlbumTracksController(ITrackService trackService, ILogger<AlbumTracksController> logger)
    {
        _trackService = trackService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<TrackResponse>>> GetTracksByAlbum(int albumId)
    {
        var tracks = await _trackService.GetTracksByAlbumAsync(albumId);
        var response = tracks.Select(t => new TrackResponse
        {
            TrackId = t.TrackId,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t.AlbumTitle,
            GenreId = t.GenreId,
            GenreName = t.GenreName,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists
        }).ToList();

        return Ok(response);
    }
}
