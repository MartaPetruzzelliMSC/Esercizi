using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Requests;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AlbumsController : ControllerBase
{
    private readonly IAlbumService _albumService;
    private readonly ILogger<AlbumsController> _logger;

    public AlbumsController(IAlbumService albumService, ILogger<AlbumsController> logger)
    {
        _albumService = albumService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<AlbumResponse>>> GetAll()
    {
        var albums = await _albumService.GetAllAlbumsAsync();
        var response = albums.Select(a => new AlbumResponse
        {
            AlbumId = a.AlbumId,
            Title = a.Title,
            ReleaseYear = a.ReleaseYear,
            TracksCount = a.TracksCount
        }).ToList();

        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<AlbumResponse>> GetById(int id)
    {
        var album = await _albumService.GetAlbumByIdAsync(id);
        
        if (album == null)
            return NotFound();

        var response = new AlbumResponse
        {
            AlbumId = album.AlbumId,
            Title = album.Title,
            ReleaseYear = album.ReleaseYear,
            TracksCount = album.TracksCount
        };

        return Ok(response);
    }

    [HttpGet("by-year/{year}")]
    public async Task<ActionResult<List<AlbumResponse>>> GetByYear(int year)
    {
        var albums = await _albumService.GetAlbumsByYearAsync(year);
        var response = albums.Select(a => new AlbumResponse
        {
            AlbumId = a.AlbumId,
            Title = a.Title,
            ReleaseYear = a.ReleaseYear,
            TracksCount = a.TracksCount
        }).ToList();

        return Ok(response);
    }

    [HttpPost]
    public async Task<ActionResult<AlbumResponse>> Create([FromBody] CreateAlbumRequest request)
    {
        var albumDto = new AlbumDto
        {
            Title = request.Title,
            ReleaseYear = request.ReleaseYear
        };

        var createdAlbum = await _albumService.CreateAlbumAsync(albumDto);

        var response = new AlbumResponse
        {
            AlbumId = createdAlbum.AlbumId,
            Title = createdAlbum.Title,
            ReleaseYear = createdAlbum.ReleaseYear,
            TracksCount = createdAlbum.TracksCount
        };

        return CreatedAtAction(nameof(GetById), new { id = response.AlbumId }, response);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<AlbumResponse>> Update(int id, [FromBody] UpdateAlbumRequest request)
    {
        var albumDto = new AlbumDto
        {
            Title = request.Title,
            ReleaseYear = request.ReleaseYear
        };

        var updatedAlbum = await _albumService.UpdateAlbumAsync(id, albumDto);

        if (updatedAlbum == null)
            return NotFound();

        var response = new AlbumResponse
        {
            AlbumId = updatedAlbum.AlbumId,
            Title = updatedAlbum.Title,
            ReleaseYear = updatedAlbum.ReleaseYear,
            TracksCount = updatedAlbum.TracksCount
        };

        return Ok(response);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var deleted = await _albumService.DeleteAlbumAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
