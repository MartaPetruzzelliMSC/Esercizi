using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Requests;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TracksController : ControllerBase
{
    private readonly ITrackService _trackService;
    private readonly ILogger<TracksController> _logger;

    public TracksController(ITrackService trackService, ILogger<TracksController> logger)
    {
        _trackService = trackService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<TrackResponse>>> GetAll()
    {
        var tracks = await _trackService.GetAllTracksAsync();
        var response = tracks.Select(t => new TrackResponse
        {
            TrackId = t.TrackId,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t.AlbumTitle,
            GenreId = t.GenreId,
            GenreName = t.GenreName,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists
        }).ToList();

        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<TrackResponse>> GetById(int id)
    {
        var track = await _trackService.GetTrackByIdAsync(id);
        
        if (track == null)
            return NotFound();

        var response = new TrackResponse
        {
            TrackId = track.TrackId,
            Title = track.Title,
            AlbumId = track.AlbumId,
            AlbumTitle = track.AlbumTitle,
            GenreId = track.GenreId,
            GenreName = track.GenreName,
            DurationSeconds = track.DurationSeconds,
            Artists = track.Artists
        };

        return Ok(response);
    }

    [HttpPost]
    public async Task<ActionResult<TrackResponse>> Create([FromBody] CreateTrackRequest request)
    {
        var trackDto = new TrackDto
        {
            Title = request.Title,
            AlbumId = request.AlbumId,
            GenreId = request.GenreId,
            DurationSeconds = request.DurationSeconds
        };

        var createdTrack = await _trackService.CreateTrackAsync(trackDto);

        var response = new TrackResponse
        {
            TrackId = createdTrack.TrackId,
            Title = createdTrack.Title,
            AlbumId = createdTrack.AlbumId,
            AlbumTitle = createdTrack.AlbumTitle,
            GenreId = createdTrack.GenreId,
            GenreName = createdTrack.GenreName,
            DurationSeconds = createdTrack.DurationSeconds,
            Artists = createdTrack.Artists
        };

        return CreatedAtAction(nameof(GetById), new { id = response.TrackId }, response);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<TrackResponse>> Update(int id, [FromBody] UpdateTrackRequest request)
    {
        var trackDto = new TrackDto
        {
            Title = request.Title,
            AlbumId = request.AlbumId,
            GenreId = request.GenreId,
            DurationSeconds = request.DurationSeconds
        };

        var updatedTrack = await _trackService.UpdateTrackAsync(id, trackDto);

        if (updatedTrack == null)
            return NotFound();

        var response = new TrackResponse
        {
            TrackId = updatedTrack.TrackId,
            Title = updatedTrack.Title,
            AlbumId = updatedTrack.AlbumId,
            AlbumTitle = updatedTrack.AlbumTitle,
            GenreId = updatedTrack.GenreId,
            GenreName = updatedTrack.GenreName,
            DurationSeconds = updatedTrack.DurationSeconds,
            Artists = updatedTrack.Artists
        };

        return Ok(response);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var deleted = await _trackService.DeleteTrackAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
