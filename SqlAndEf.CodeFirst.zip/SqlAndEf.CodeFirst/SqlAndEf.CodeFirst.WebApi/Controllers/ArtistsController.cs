using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Requests;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ArtistsController : ControllerBase
{
    private readonly IArtistService _artistService;
    private readonly ILogger<ArtistsController> _logger;

    public ArtistsController(IArtistService artistService, ILogger<ArtistsController> logger)
    {
        _artistService = artistService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<ArtistResponse>>> GetAll()
    {
        var artists = await _artistService.GetAllArtistsAsync();
        var response = artists.Select(a => new ArtistResponse
        {
            ArtistId = a.ArtistId,
            Name = a.Name,
            Country = a.Country,
            TracksCount = a.TracksCount
        }).ToList();

        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ArtistResponse>> GetById(int id)
    {
        var artist = await _artistService.GetArtistByIdAsync(id);
        
        if (artist == null)
            return NotFound();

        var response = new ArtistResponse
        {
            ArtistId = artist.ArtistId,
            Name = artist.Name,
            Country = artist.Country,
            TracksCount = artist.TracksCount
        };

        return Ok(response);
    }

    [HttpGet("by-country/{country}")]
    public async Task<ActionResult<List<ArtistResponse>>> GetByCountry(string country)
    {
        var artists = await _artistService.GetArtistsByCountryAsync(country);
        var response = artists.Select(a => new ArtistResponse
        {
            ArtistId = a.ArtistId,
            Name = a.Name,
            Country = a.Country,
            TracksCount = a.TracksCount
        }).ToList();

        return Ok(response);
    }

    [HttpPost]
    public async Task<ActionResult<ArtistResponse>> Create([FromBody] CreateArtistRequest request)
    {
        var artistDto = new ArtistDto
        {
            Name = request.Name,
            Country = request.Country
        };

        var createdArtist = await _artistService.CreateArtistAsync(artistDto);

        var response = new ArtistResponse
        {
            ArtistId = createdArtist.ArtistId,
            Name = createdArtist.Name,
            Country = createdArtist.Country,
            TracksCount = createdArtist.TracksCount
        };

        return CreatedAtAction(nameof(GetById), new { id = response.ArtistId }, response);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<ArtistResponse>> Update(int id, [FromBody] UpdateArtistRequest request)
    {
        var artistDto = new ArtistDto
        {
            Name = request.Name,
            Country = request.Country
        };

        var updatedArtist = await _artistService.UpdateArtistAsync(id, artistDto);

        if (updatedArtist == null)
            return NotFound();

        var response = new ArtistResponse
        {
            ArtistId = updatedArtist.ArtistId,
            Name = updatedArtist.Name,
            Country = updatedArtist.Country,
            TracksCount = updatedArtist.TracksCount
        };

        return Ok(response);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var deleted = await _artistService.DeleteArtistAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
