using Microsoft.AspNetCore.Mvc;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.BusinessLogic.Services;
using SqlAndEf.CodeFirst.WebApi.Models.Requests;
using SqlAndEf.CodeFirst.WebApi.Models.Responses;

namespace SqlAndEf.CodeFirst.WebApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GenresController : ControllerBase
{
    private readonly IGenreService _genreService;
    private readonly ILogger<GenresController> _logger;

    public GenresController(IGenreService genreService, ILogger<GenresController> logger)
    {
        _genreService = genreService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<List<GenreResponse>>> GetAll()
    {
        var genres = await _genreService.GetAllGenresAsync();
        var response = genres.Select(g => new GenreResponse
        {
            GenreId = g.GenreId,
            Name = g.Name,
            TracksCount = g.TracksCount
        }).ToList();

        return Ok(response);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<GenreResponse>> GetById(int id)
    {
        var genre = await _genreService.GetGenreByIdAsync(id);
        
        if (genre == null)
            return NotFound();

        var response = new GenreResponse
        {
            GenreId = genre.GenreId,
            Name = genre.Name,
            TracksCount = genre.TracksCount
        };

        return Ok(response);
    }

    [HttpPost]
    public async Task<ActionResult<GenreResponse>> Create([FromBody] CreateGenreRequest request)
    {
        var genreDto = new GenreDto
        {
            Name = request.Name
        };

        var createdGenre = await _genreService.CreateGenreAsync(genreDto);

        var response = new GenreResponse
        {
            GenreId = createdGenre.GenreId,
            Name = createdGenre.Name,
            TracksCount = createdGenre.TracksCount
        };

        return CreatedAtAction(nameof(GetById), new { id = response.GenreId }, response);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<GenreResponse>> Update(int id, [FromBody] UpdateGenreRequest request)
    {
        var genreDto = new GenreDto
        {
            Name = request.Name
        };

        var updatedGenre = await _genreService.UpdateGenreAsync(id, genreDto);

        if (updatedGenre == null)
            return NotFound();

        var response = new GenreResponse
        {
            GenreId = updatedGenre.GenreId,
            Name = updatedGenre.Name,
            TracksCount = updatedGenre.TracksCount
        };

        return Ok(response);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> Delete(int id)
    {
        var deleted = await _genreService.DeleteGenreAsync(id);

        if (!deleted)
            return NotFound();

        return NoContent();
    }
}
