﻿using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Context
{
    public class MusicDbContext : DbContext
    {
        public MusicDbContext(DbContextOptions<MusicDbContext> options) : base(options)
        {
        }

        public DbSet<Album> Albums { get; set; }
        public DbSet<Artist> Artists { get; set; }
        public DbSet<Genre> Genres { get; set; }
        public DbSet<Track> Tracks { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Track>()
                .HasOne(t => t.Genre)
                .WithMany(g => g.Tracks)
                .HasForeignKey(t => t.GenreId).IsRequired()
                .OnDelete(DeleteBehavior.Restrict); // riassegna le track prima di eliminare un genere

            modelBuilder.Entity<Track>()
               .HasOne(t => t.Album)
               .WithMany(g => g.Tracks)
               .HasForeignKey(t => t.AlbumId)
               .OnDelete(DeleteBehavior.SetNull);

            //modelBuilder.Entity<Genre>() // da many to one, ma si mappa da un lato solo
            //    .HasMany(g => g.Tracks)
            //    .WithOne(t => t.Genre);

            //modelBuilder.Entity<Album>()
            //    .HasMany(a => a.Tracks)
            //    .WithOne(t => t.Album);

            modelBuilder.Entity<Artist>()
                .HasMany(a => a.Tracks)
                .WithMany(t => t.Artists)
                .UsingEntity("TrackAuthors",
                    l => l.HasOne(typeof(Track)).WithMany().HasForeignKey("TrackId").IsRequired().HasPrincipalKey(nameof(Track.Id)).OnDelete(DeleteBehavior.Cascade),
                    r => r.HasOne(typeof(Artist)).WithMany().HasForeignKey("ArtistId").IsRequired().HasPrincipalKey(nameof(Artist.Id)).OnDelete(DeleteBehavior.Cascade),
                    i => {
                        i.IndexerProperty<int>("TrackAuthorId");
                        i.HasKey("TrackAuthorId");
                        }
                    );

            //modelBuilder.Entity<Genre>()
            //    .Property(g => g.Name)
            //    .HasColumnType("nvarchar(50)");

        }
    }
}
