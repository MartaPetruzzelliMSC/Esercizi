﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Genre : BaseEntity
    {
        [Required]
        [Column(TypeName = ("nvarchar(50)"))]
        public string Name { get; set; }

        public virtual IEnumerable<Track> Tracks { get; set; } = new List<Track>();

    }
}
