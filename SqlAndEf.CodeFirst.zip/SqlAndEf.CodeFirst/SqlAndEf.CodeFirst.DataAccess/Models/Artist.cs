﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Artist : BaseEntity
    {
        [Required]
        [Column(TypeName = ("nvarchar(50)"))]
        public string Name { get; set; }

        [Required]
        [Column(TypeName = ("nvarchar(50)"))]
        public string Country { get; set; }

        public virtual ICollection<Track> Tracks { get; set; } = new List<Track>();

    }
}
