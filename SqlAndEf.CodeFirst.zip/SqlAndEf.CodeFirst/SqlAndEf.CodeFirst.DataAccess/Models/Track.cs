﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Track : BaseEntity
    {
        [Column(TypeName = ("nvarchar(50)"))]
        [Required]
        public string Title { get; set; }
        
        public int? AlbumId { get; set; }

        [Required]
        public int GenreId { get; set; }
        
        [Required]
        public int DurationSeconds { get; set; }

        public virtual Genre Genre { get; set; }
        public virtual Album Album { get; set; }

        public virtual ICollection<Artist> Artists { get; set; } = new List<Artist>();

    }
}
