﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public abstract class BaseEntity
    {
        [Required]
        public int Id { get; set; }
        [Required]
        [Column(TypeName = ("datetime"))]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        [Required]
        [Column(TypeName = ("datetime"))]
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
