﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlAndEf.CodeFirst.DataAccess.Models
{
    public class Album : BaseEntity
    {
        [Required]
        [Column(TypeName = ("nvarchar(50)"))]
        public string Title { get; set; }
        
        [Required]
        public int ReleaseYear { get; set; }

        public virtual IEnumerable<Track> Tracks { get; set; } = new List<Track>();
    }
}
