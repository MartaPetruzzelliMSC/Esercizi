using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services;

public interface IAlbumService
{
    Task<List<AlbumDto>> GetAllAlbumsAsync();
    Task<AlbumDto> GetAlbumByIdAsync(int id);
    Task<AlbumDto> CreateAlbumAsync(AlbumDto album);
    Task<AlbumDto> UpdateAlbumAsync(int id, AlbumDto album);
    Task<bool> DeleteAlbumAsync(int id);
    Task<List<AlbumDto>> GetAlbumsByYearAsync(int year);
}
