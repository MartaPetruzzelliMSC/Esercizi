using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services;

public interface ITrackAuthorService
{
    Task<List<TrackAuthorDto>> GetAllTrackAuthorsAsync();
    Task<TrackAuthorDto> GetTrackAuthorByIdAsync(int artistId, int trackId);
    Task<TrackAuthorDto> CreateTrackAuthorAsync(TrackAuthorDto trackAuthor);
    Task<bool> DeleteTrackAuthorAsync(int artistId, int trackId);
    Task<List<TrackAuthorDto>> GetAuthorsByTrackAsync(int trackId);
    Task<List<TrackAuthorDto>> GetTracksByArtistAsync(int artistId);
}
