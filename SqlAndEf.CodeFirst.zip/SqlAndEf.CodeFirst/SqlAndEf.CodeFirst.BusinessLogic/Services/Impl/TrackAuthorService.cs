using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Context;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class TrackAuthorService : ITrackAuthorService
{
    private readonly MusicDbContext _context;

    public TrackAuthorService(MusicDbContext context)
    {
        _context = context;
    }

    // TODO: Implementare i metodi usando Entity Framework Core

    public async Task<List<TrackAuthorDto>> GetAllTrackAuthorsAsync()
    {
        var a = await _context.Tracks.AsNoTracking()
            .Include(x => x.Artists)
            .Select(y => y.Artists.Select(z => new TrackAuthorDto
            {
                TrackId = y.Id,
                TrackTitle = y.Title,
                ArtistId = z.Id,
                ArtistName = z.Name
            })).SelectMany(ta => ta).ToListAsync();

        return a;
    }

    public async Task<TrackAuthorDto> GetTrackAuthorByIdAsync(int artistId, int trackId) //non si pu� fare senza entit� trackauthors nel context
    {
        // manca controllo che artist o track non siano nulle prima di cercare il trackauthor
        var a = await _context.Tracks.AsNoTracking()
            .Include(x => x.Artists.Where(t => t.Id == artistId))
            .Where(t => t.Id == trackId)
            .Select(y => new TrackAuthorDto
            {
                TrackId = y.Id,
                TrackTitle = y.Title,
                ArtistId = y.Artists.FirstOrDefault(t => t.Id == artistId).Id,
                ArtistName = y.Artists.FirstOrDefault(t => t.Id == artistId).Name
            }).FirstOrDefaultAsync();

        return a;
    }

    public async Task<TrackAuthorDto> CreateTrackAuthorAsync(TrackAuthorDto trackAuthor)
    {
        var t = await _context.Tracks.FindAsync(trackAuthor.TrackId);
        var a = await _context.Artists.FindAsync(trackAuthor.ArtistId);
        t.Artists.Add(a);
        a.Tracks.Add(t);
        _context.Entry(t).State = EntityState.Modified;
        _context.Entry(a).State = EntityState.Modified;
        await _context.SaveChangesAsync();

        return new TrackAuthorDto
        {
            TrackId = t.Id,
            TrackTitle = t.Title,
            ArtistId = a.Id,
            ArtistName = a.Name
        };

    }

    public async Task<bool> DeleteTrackAuthorAsync(int artistId, int trackId)
    {
        var a = await _context.Tracks.AsNoTracking()
            .Include(x => x.Artists.Where(t => t.Id == artistId))
            .Where(t => t.Id == trackId)
            .SingleAsync();
        if(a == null) { return false; }
        _context.Remove(a);

        _context.Entry(a).State = EntityState.Deleted;

        return true;
    }

    public async Task<List<TrackAuthorDto>> GetAuthorsByTrackAsync(int trackId)
    {
        var t = await _context.Tracks.AsNoTracking()
        .Include(x => x.Artists)
            .FirstAsync(y => y.Id == trackId);

        var a = t.Artists.Select(y => new TrackAuthorDto
        {
            TrackId = t.Id,
            TrackTitle = t.Title,
            ArtistId = y.Id,
            ArtistName = y.Name
        }).ToList();
        return a;
    }

    public async Task<List<TrackAuthorDto>> GetTracksByArtistAsync(int artistId)
    {
        var a = await _context.Artists.AsNoTracking()
            .Include(x => x.Tracks)
            .FirstAsync(y => y.Id == artistId);

        var t = a.Tracks.Select(y => new TrackAuthorDto
        {
            TrackId = y.Id,
            TrackTitle = y.Title,
            ArtistId = a.Id,
            ArtistName = a.Name
        }).ToList();
        return t;
    }
}
