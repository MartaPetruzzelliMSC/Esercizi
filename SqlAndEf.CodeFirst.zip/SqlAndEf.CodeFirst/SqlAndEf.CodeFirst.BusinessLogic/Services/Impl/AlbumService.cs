using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Context;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class AlbumService : IAlbumService
{
    private readonly MusicDbContext _context;

    public AlbumService(MusicDbContext context)
    {
        _context = context;
    }

    // TODO: Implementare i metodi usando Entity Framework Core

    public Task<List<AlbumDto>> GetAllAlbumsAsync()
    {
        throw new NotImplementedException();
    }

    public Task<AlbumDto> GetAlbumByIdAsync(int id)
    {
        throw new NotImplementedException();
    }

    public async Task<AlbumDto> CreateAlbumAsync(AlbumDto album)
    {
        var a = _context.Albums.Add(new Album
        {
            Title = album.Title,
            ReleaseYear = album.ReleaseYear
        }).Entity;

        await _context.SaveChangesAsync();

        return new AlbumDto
        {
            AlbumId = a.Id,
            Title = a.Title,
            ReleaseYear = a.ReleaseYear,
            TracksCount = a.Tracks.Count()
        };
    }

    public Task<AlbumDto> UpdateAlbumAsync(int id, AlbumDto album)
    {
        throw new NotImplementedException();
    }

    public Task<bool> DeleteAlbumAsync(int id)
    {
        throw new NotImplementedException();
    }

    public Task<List<AlbumDto>> GetAlbumsByYearAsync(int year)
    {
        throw new NotImplementedException();
    }
}
