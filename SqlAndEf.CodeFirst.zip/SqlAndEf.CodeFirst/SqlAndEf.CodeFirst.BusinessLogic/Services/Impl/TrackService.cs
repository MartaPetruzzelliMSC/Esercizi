using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Context;
using SqlAndEf.CodeFirst.DataAccess.Models;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class TrackService : ITrackService
{
    private readonly MusicDbContext _context;

    public TrackService(MusicDbContext context)
    {
        _context = context;
    }

    // TODO: Implementare i metodi usando Entity Framework Core

    public async Task<List<TrackDto>> GetAllTracksAsync()
    {
        var g = _context.Tracks.AsNoTracking()
            .Select(y => new TrackDto
            {
                TrackId = y.Id,
                Title = y.Title,
                AlbumId = y.AlbumId,
                AlbumTitle = y.Album.Title,
                GenreId = y.GenreId,
                GenreName = y.Genre.Name,
                DurationSeconds = y.DurationSeconds,
                Artists = y.Artists.Select(z => z.Name).ToList()
            });
        return await g.ToListAsync();
    }

    public async Task<TrackDto> GetTrackByIdAsync(int id)
    {
        var t = await _context.Tracks.AsNoTracking()
            .Select(y => new TrackDto
            {
                TrackId = y.Id,
                Title = y.Title,
                AlbumId = y.AlbumId,
                AlbumTitle = y.Album.Title,
                GenreId = y.GenreId,
                GenreName = y.Genre.Name,
                DurationSeconds = y.DurationSeconds,
                Artists = y.Artists.Select(z => z.Name).ToList()
            })
            .SingleAsync(x => x.TrackId == id);
        return t;
    }

    public async Task<TrackDto> CreateTrackAsync(TrackDto track)
    {
        var t = _context.Tracks.Add(new Track
        {
            Title = track.Title,
            AlbumId = track.AlbumId,
            GenreId = track.GenreId,
            DurationSeconds = track.DurationSeconds
        }).Entity;

        await _context.SaveChangesAsync();

        var t2 = _context.Tracks.Include(t => t.Album).Include(t => t.Genre).Single(tt => tt.Id == t.Id);
        var dto = new TrackDto
        {
            TrackId = t.Id,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t2.Album.Title,
            GenreId = t.GenreId,
            GenreName = t2.Genre.Name,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists.Select(z => z.Name).ToList()
        };

        return dto;
    }

    public async Task<TrackDto> UpdateTrackAsync(int id, TrackDto track)
    {
        var t = await _context.Tracks.FindAsync(id) ?? throw new InvalidOperationException();

        t.Title = track.Title;
        t.AlbumId = track.AlbumId;
        t.GenreId = track.GenreId;
        t.DurationSeconds = track.DurationSeconds;

        _context.Entry(t).State = EntityState.Modified;

        await _context.SaveChangesAsync();

        return new TrackDto
        {
            TrackId = t.Id,
            Title = t.Title,
            AlbumId = t.AlbumId,
            AlbumTitle = t.Album.Title,
            GenreId = t.GenreId,
            GenreName = t.Genre.Name,
            DurationSeconds = t.DurationSeconds,
            Artists = t.Artists.Select(z => z.Name).ToList()
        };
    }

    public async Task<bool> DeleteTrackAsync(int id)
    {
        var t = await _context.Tracks.FindAsync(id);
        if (t == null) { return false; }
        _context.Tracks.Remove(t);

        _context.Entry(t).State = EntityState.Deleted;

        await _context.SaveChangesAsync();

        return true;
    }

    public async Task<List<TrackDto>> GetTracksByGenreAsync(int genreId)
    {
        var t = _context.Tracks.AsNoTracking()
          .Select(y => new TrackDto
          {
              TrackId = y.Id,
              Title = y.Title,
              AlbumId = y.AlbumId,
              AlbumTitle = y.Album.Title,
              GenreId = y.GenreId,
              GenreName = y.Genre.Name,
              DurationSeconds = y.DurationSeconds,
              Artists = y.Artists.Select(z => z.Name).ToList()
          }).Where(x => x.GenreId == genreId);
        return await t.ToListAsync();
    }

    public async Task<List<TrackDto>> GetTracksByAlbumAsync(int albumId)
    {
        var t = _context.Tracks.AsNoTracking()
          .Select(y => new TrackDto
          {
              TrackId = y.Id,
              Title = y.Title,
              AlbumId = y.AlbumId,
              AlbumTitle = y.Album.Title,
              GenreId = y.GenreId,
              GenreName = y.Genre.Name,
              DurationSeconds = y.DurationSeconds,
              Artists = y.Artists.Select(z => z.Name).ToList()
          }).Where(y => y.AlbumId == albumId);
        return await t.ToListAsync();
    }

    public async Task<List<TrackDto>> GetTracksByArtistAsync(int artistId)
    {
        var a = await _context.Artists.AsNoTracking()
            .Include(x => x.Tracks)
            .FirstAsync(y => y.Id == artistId);

        var t = a.Tracks.Select(y => new TrackDto
                {
                    TrackId = y.Id,
                    Title = y.Title,
                    AlbumId = y.AlbumId,
                    AlbumTitle = y.Album.Title,
                    GenreId = y.GenreId,
                    GenreName = y.Genre.Name,
                    DurationSeconds = y.DurationSeconds,
                    Artists = y.Artists.Select(z => z.Name).ToList()
                }).ToList();
        return t;
    }
}
