using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Context;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class GenreService : IGenreService
{
    private readonly MusicDbContext _context;

    public GenreService(MusicDbContext context)
    {
        _context = context;
    }
          
    // TODO: Implementare i metodi usando Entity Framework Core

    public async Task<List<GenreDto>> GetAllGenresAsync()
    {
        var g = _context.Genres.AsNoTracking()
            .Select(x => new GenreDto
            {
                GenreId = x.Id,
                Name = x.Name,
                TracksCount = x.Tracks.Count()
            });
        return await g.ToListAsync();
    }

    public async Task<GenreDto> GetGenreByIdAsync(int id)
    {
        var g = await _context.Genres.AsNoTracking()
            .Select(x => new GenreDto
            {
                GenreId = x.Id,
                Name = x.Name,
                TracksCount = x.Tracks.Count()
            }).SingleAsync(x => x.GenreId == id);
        return g;
    }

    public async Task<GenreDto> CreateGenreAsync(GenreDto genre)
    {
        var g = _context.Genres.Add(new Genre
        {
            Name = genre.Name
        }).Entity;

        await _context.SaveChangesAsync();

        return new GenreDto
        {
            GenreId = g.Id,
            Name = g.Name,
            TracksCount = g.Tracks.Count()
        };
    }

    public async Task<GenreDto> UpdateGenreAsync(int id, GenreDto genre)
    {
        var g = await _context.Genres.FindAsync(id) ?? throw new InvalidOperationException();

        g.Name = genre.Name;

        _context.Entry(g).State = EntityState.Modified;

        await _context.SaveChangesAsync();

        return new GenreDto
        {
            GenreId = g.Id,
            Name = g.Name,
            TracksCount = g.Tracks.Count()
        };
    }

    public async Task<bool> DeleteGenreAsync(int id)
    {
        var g = await _context.Genres.FindAsync(id);
        if(g == null) { return false; }
        _context.Genres.Remove(g);

        _context.Entry(g).State = EntityState.Deleted;

        await _context.SaveChangesAsync();

        return true;
    }
}
