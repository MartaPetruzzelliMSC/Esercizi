using Microsoft.EntityFrameworkCore;
using SqlAndEf.CodeFirst.BusinessLogic.Models;
using SqlAndEf.CodeFirst.DataAccess.Context;
using SqlAndEf.CodeFirst.DataAccess.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services.Impl;

public class ArtistService : IArtistService
{
    private readonly MusicDbContext _context;

    public ArtistService(MusicDbContext context)
    {
        _context = context;
    }

    public async Task<List<ArtistDto>> GetAllArtistsAsync()
    {
        var a = _context.Artists.AsNoTracking()
           .Select(x => new ArtistDto
           {
               ArtistId = x.Id,
               Name = x.Name,
               Country = x.Country,
               TracksCount = x.Tracks.Count()
           });
        return await a.ToListAsync();
    }

    public async Task<ArtistDto> GetArtistByIdAsync(int id)
    {
        var a = await _context.Artists.AsNoTracking()
           .Select(x => new ArtistDto
           {
               ArtistId = x.Id,
               Name = x.Name,
               Country = x.Country,
               TracksCount = x.Tracks.Count()
           }).SingleAsync(x => x.ArtistId == id);

        return a;
    }

    public async Task<ArtistDto> CreateArtistAsync(ArtistDto artist)
    {
        var a = _context.Artists.Add(new Artist
        {
            Name = artist.Name,
            Country = artist.Country
        }).Entity;

        await _context.SaveChangesAsync();

        return new ArtistDto
        {
            ArtistId = a.Id,
            Name = a.Name,
            Country = a.Country,
            TracksCount = a.Tracks.Count()
        };
    }

    public async Task<ArtistDto> UpdateArtistAsync(int id, ArtistDto artist)
    {
        var a = await _context.Artists.FindAsync(id) ?? throw new InvalidOperationException();

        a.Name = artist.Name;

        _context.Entry(a).State = EntityState.Modified;

        await _context.SaveChangesAsync();

        return new ArtistDto
        {
            ArtistId = a.Id,
            Name = a.Name,
            Country = a.Country,
            TracksCount = a.Tracks.Count()
        };
    }

    public async Task<bool> DeleteArtistAsync(int id)
    {
        var a = await _context.Artists.FindAsync(id);
        if (a == null) { return false; }
        _context.Artists.Remove(a);

        _context.Entry(a).State = EntityState.Deleted;

        await _context.SaveChangesAsync();

        return true;
    }

    public async Task<List<ArtistDto>> GetArtistsByCountryAsync(string country)
    {
        var a = _context.Artists.AsNoTracking()
          .Select(x => new ArtistDto
          {
              ArtistId = x.Id,
              Name = x.Name,
              Country = x.Country,
              TracksCount = x.Tracks.Count()
          }).Where(x => x.Country.Equals(country));
        return await a.ToListAsync();
    }
}
