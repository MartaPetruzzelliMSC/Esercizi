using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services;

public interface IGenreService
{
    Task<List<GenreDto>> GetAllGenresAsync();
    Task<GenreDto> GetGenreByIdAsync(int id);
    Task<GenreDto> CreateGenreAsync(GenreDto genre);
    Task<GenreDto> UpdateGenreAsync(int id, GenreDto genre);
    Task<bool> DeleteGenreAsync(int id);
}
