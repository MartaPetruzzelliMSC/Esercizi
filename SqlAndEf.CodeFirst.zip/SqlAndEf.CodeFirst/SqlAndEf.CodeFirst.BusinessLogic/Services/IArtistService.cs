using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services;

public interface IArtistService
{
    Task<List<ArtistDto>> GetAllArtistsAsync();
    Task<ArtistDto> GetArtistByIdAsync(int id);
    Task<ArtistDto> CreateArtistAsync(ArtistDto artist);
    Task<ArtistDto> UpdateArtistAsync(int id, ArtistDto artist);
    Task<bool> DeleteArtistAsync(int id);
    Task<List<ArtistDto>> GetArtistsByCountryAsync(string country);
}
