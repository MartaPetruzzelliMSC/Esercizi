using SqlAndEf.CodeFirst.BusinessLogic.Models;

namespace SqlAndEf.CodeFirst.BusinessLogic.Services;

public interface ITrackService
{
    Task<List<TrackDto>> GetAllTracksAsync();
    Task<TrackDto> GetTrackByIdAsync(int id);
    Task<TrackDto> CreateTrackAsync(TrackDto track);
    Task<TrackDto> UpdateTrackAsync(int id, TrackDto track);
    Task<bool> DeleteTrackAsync(int id);
    Task<List<TrackDto>> GetTracksByGenreAsync(int genreId);
    Task<List<TrackDto>> GetTracksByAlbumAsync(int albumId);
    Task<List<TrackDto>> GetTracksByArtistAsync(int artistId);
}
