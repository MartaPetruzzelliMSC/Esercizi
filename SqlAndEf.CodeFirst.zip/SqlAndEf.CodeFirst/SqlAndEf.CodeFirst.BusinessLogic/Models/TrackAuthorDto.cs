namespace SqlAndEf.CodeFirst.BusinessLogic.Models;

public class TrackAuthorDto
{
    public int TrackAuthorId { get; set; }
    public int TrackId { get; set; }
    public string TrackTitle { get; set; }
    public int ArtistId { get; set; }
    public string ArtistName { get; set; }
}
