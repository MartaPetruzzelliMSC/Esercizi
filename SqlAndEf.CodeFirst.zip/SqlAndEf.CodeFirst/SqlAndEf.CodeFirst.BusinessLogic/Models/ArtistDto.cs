namespace SqlAndEf.CodeFirst.BusinessLogic.Models;

public class ArtistDto
{
    public int ArtistId { get; set; }
    public string Name { get; set; }
    public string Country { get; set; }
    public int TracksCount { get; set; }
}
