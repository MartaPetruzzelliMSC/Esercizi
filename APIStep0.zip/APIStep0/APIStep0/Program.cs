﻿using System.Text.Json;
using System.Threading.Tasks;

namespace APIStep0
{
    internal class Program
    {
        public class WeatherForecast
        {
            public DateOnly Date { get; set; }

            public int TemperatureC { get; set; }

            public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

            public string? Summary { get; set; }
        }
        public class WeatherForecastDto
        {
            public DateOnly Date { get; set; }

            public int TemperatureC { get; set; }

        }
        static async Task Main(string[] args)
        {
            using var client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:5256");

            try
            {
                var response = await client.GetAsync("/WeatherForecast");
                //response.EnsureSuccessStatusCode();
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync(); // richiede esplicitamente la risposta dal browser - me la ritorna come testo
                
                    var forecasts = JsonSerializer.Deserialize<WeatherForecast[]>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    foreach (var forecast in forecasts)
                    {
                        Console.WriteLine($"Date: {forecast.Date}\nTemperatureC: {forecast.TemperatureC}\nTemperatureF: {forecast.TemperatureF}\nSummary: {forecast.Summary}");
                    }
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }

                
            }
            catch (Exception)
            {

                throw;
            }

            try
            {
                var content = new StringContent("a", System.Text.Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/WeatherForecast/postOk", content);
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync(); // richiede esplicitamente la risposta dal browser - me la ritorna come testo

                    var forecast = JsonSerializer.Deserialize<WeatherForecastDto>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                    
                    Console.WriteLine($"Date: {forecast.Date}\nTemperatureC: {forecast.TemperatureC}");
                    
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
