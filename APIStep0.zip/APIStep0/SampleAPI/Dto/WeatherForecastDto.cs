﻿namespace SampleAPI.Dto
{
    public class WeatherForecastDto
    {
        public DateOnly Date { get; set; }

        public int TemperatureC { get; set; }

    }
}
