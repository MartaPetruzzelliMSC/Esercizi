﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SampleAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : ControllerBase
    {
        // GET: api/<TestController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<TestController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }
        
        // GET api/<TestController>/5
        [HttpGet("{id1}/{id2}")]
        public ActionResult<string> Get2(int id1, int id2, [FromBody] string value)
        {
            return $"id1 : {id1} \nid2 : {id2} \nvalue : {value}";
        }

        // POST api/<TestController>
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<TestController>/5
        [HttpPut]
        public void Put([FromBody]string value)
        {
        }

        // DELETE api/<TestController>/5
        [HttpDelete]
        [Route("delete/{id}/{id2}")]
        public void Delete(int id, int id2)
        {
        }
    }
}
