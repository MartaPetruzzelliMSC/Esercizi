using Microsoft.AspNetCore.Mvc;
using SampleAPI.Dto;

namespace SampleAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    public static List<UpdatableWeatherForecast> UWeatherForecast = new()
    {
        new UpdatableWeatherForecast{ Id = 1, Date = DateOnly.FromDateTime(DateTime.Now), TemperatureC = 20, Summary = "Freschino"},
        new UpdatableWeatherForecast{ Id = 2, Date = DateOnly.FromDateTime(DateTime.Now), TemperatureC = 30, Summary = "Caldino"},
        new UpdatableWeatherForecast{ Id = 3, Date = DateOnly.FromDateTime(DateTime.Now), TemperatureC = 10, Summary = "Freddino"},
        new UpdatableWeatherForecast{ Id = 4, Date = DateOnly.FromDateTime(DateTime.Now), TemperatureC = 40, Summary = "Caldone"}
    };

    private static readonly string[] Summaries = new[]
    {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    [HttpGet(Name = "GetWeatherForecast")]
    public IEnumerable<WeatherForecast> Get()
    {
        return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();
    }
    
    [HttpGet]
    [Route("getOk")]
    public ActionResult<IEnumerable<WeatherForecast>> GetOk()
    {
        var a = Enumerable.Range(1, 5).Select(index => new WeatherForecast
        {
            Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            TemperatureC = Random.Shared.Next(-20, 55),
            Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        })
        .ToArray();

        return BadRequest(new {StatusCodes.Status418ImATeapot});
    }

    [HttpPost]
    [Route("postOk")]
    public ActionResult<WeatherForecastDto> CreateWeatherForescast([FromBody] WeatherForecast wf)
    {
        var dto = new WeatherForecastDto
        {
            Date = wf.Date,
            TemperatureC = wf.TemperatureC
        };

        return Ok(dto);
    }

    [HttpPut]
    [Route("putOk/{id}")]
    public ActionResult PutWeatherForecast(int id, [FromBody] WeatherForecast wf)
    {
        var x = UWeatherForecast.FirstOrDefault(y => y.Id == id);
        if(x == null)
        {
            return NotFound();
        }

        x.Summary = wf.Summary;
        x.TemperatureC = wf.TemperatureC;
        x.Date = wf.Date;
        return Ok(x);
        //return NoContent();
    }
    
    [HttpPut]
    [Route("putOk")]
    public ActionResult PutWeatherForecast2([FromBody] UpdatableWeatherForecast wf)
    {
        var x = UWeatherForecast.FirstOrDefault(y => y.Id == wf.Id);
        if(x == null)
        {
            return NotFound();
        }

        x.Summary = wf.Summary;
        x.TemperatureC = wf.TemperatureC;
        x.Date = wf.Date;
        //return Ok(x);
        return NoContent();
    }
}
