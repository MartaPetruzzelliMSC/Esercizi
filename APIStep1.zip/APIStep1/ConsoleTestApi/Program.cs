﻿using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleTestApi
{
    internal class Program
    {
        public class User
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Surname { get; set; }
            public string Email { get; set; }
            public DateOnly Birthdate { get; set; }
        }
        public class UserDto
        {
            public string Name { get; set; }
            public string Surname { get; set; }
            public string Email { get; set; }
            public DateOnly Birthdate { get; set; }
        }
        static async Task Main(string[] args)
        {
            using var client = new HttpClient();
            client.BaseAddress = new Uri("https://localhost:7111");

            try
            {
                var response = await client.GetAsync("/api/User");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var users = JsonSerializer.Deserialize<User[]>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    foreach (var user in users)
                    {
                        Console.WriteLine($"Id: {user.Id}\nName: {user.Name}\nSurname:{user.Surname}\nEmail: {user.Email}");
                    }
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }

            }
            catch (Exception)
            {

                throw;
            }

            var isId = int.TryParse(Console.ReadLine(), out int id);
            try
            {
                var response = await client.GetAsync($"/api/User/{id}");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var user = JsonSerializer.Deserialize<User>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });
                    
                    Console.WriteLine($"Id: {user.Id}\nName: {user.Name}\nSurname:{user.Surname}\nEmail: {user.Email}");
                    
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }

            }
            catch (Exception)
            {

                throw;
            }

            var name = Console.ReadLine();
            var surname = Console.ReadLine();
            var email = Console.ReadLine();
            var birthdate = DateOnly.TryParse(Console.ReadLine(), out DateOnly date);

            var uDto = new UserDto
            {
                Name = name,
                Surname = surname,
                Email = email,
                Birthdate = date
            };
            var ser = JsonSerializer.Serialize(uDto);
            try
            {
                var content = new StringContent(ser, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PostAsync("/api/User", content);
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();

                    var user = JsonSerializer.Deserialize<UserDto>(json, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    Console.WriteLine($"Name: {user.Name}\nSurname:{user.Surname}\nEmail: {user.Email}");

                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }
            }
            catch (Exception)
            {

                throw;
            }

            var isIdPut = int.TryParse(Console.ReadLine(), out int idPut);
            var name2 = Console.ReadLine();
            var surname2 = Console.ReadLine();
            var email2 = Console.ReadLine();
            var birthdate2 = DateOnly.TryParse(Console.ReadLine(), out DateOnly date2);

            var uDto2 = new UserDto
            {
                Name = name2,
                Surname = surname2,
                Email = email2,
                Birthdate = date2
            };
            var ser2 = JsonSerializer.Serialize(uDto2);
            try
            {
                var content = new StringContent(ser2, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PutAsync($"/api/User/{idPut}", content);
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }
            }
            catch (Exception)
            {

                throw;
            }

            var isIDelete = int.TryParse(Console.ReadLine(), out int idDelete);
            try
            {
                var response = await client.DeleteAsync($"/api/User/{idDelete}");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                }
                else
                {
                    Console.WriteLine($"Error Detected: {response.StatusCode}");
                }
            }
            catch (Exception)
            {

                throw;
            }
            Console.ReadLine();
        }
    }
}
