﻿namespace SampleAPI1.Dto
{
    public class UserDto
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public DateOnly Birthdate { get; set; }
    }
}
