﻿using Microsoft.AspNetCore.Mvc;
using SampleAPI1.Dto;
using SampleAPI1.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SampleAPI1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        public static List<User> UserList = new()
        {
            new User { Id = 1, Name = "Claudio", Surname = "Raciti", Email = "claudio.raciti@msc.com", Birthdate = DateOnly.FromDateTime(DateTime.Now.AddYears(7))},
            new User { Id = 2, Name = "Giacomo", Surname = "Mark", Email = "jackomino_mark@msc.com", Birthdate = DateOnly.FromDateTime(DateTime.Now.AddYears(-5))},
            new User { Id = 3, Name = "Giulio", Surname = "Pappalardo", Email = "giulio.pappalardo29@msc.com", Birthdate = new DateOnly(2003,05,29)},
            new User { Id = 4, Name = "Marta", Surname = "Petruzzelli", Email = "martapetruzzelli@msc.com", Birthdate = new DateOnly(1997,12,17)},
        };

        [HttpGet]
        public ActionResult<IEnumerable<UserDto>> GetUsers()
        {
            var users = UserList.Select(x => new UserDto
            {
                Name = x.Name,
                Surname = x.Surname,
                Email = x.Email,
                Birthdate = x.Birthdate
            }).ToList();
            return Ok(users);
        }

        [HttpGet]
        [Route("{id}")]
        public ActionResult<UserDto> GetUserById(int id)
        {
            var user = UserList
                .Where(x => x.Id == id)
                .Select(x => new UserDto
            {
                Name = x.Name,
                Surname = x.Surname,
                Email = x.Email,
                Birthdate = x.Birthdate
            }).SingleOrDefault();

            if(user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [HttpPost]
        public ActionResult<UserDto> CreateUser([FromBody]UserDto dto)
        {

            var user = new User
            {
                Id = UserList.Max(x => x.Id) + 1,
                Name = dto.Name,
                Surname = dto.Surname,
                Email = dto.Email,
                Birthdate = dto.Birthdate
            };
            UserList.Add(user);

            return Ok(user);

        }

        [HttpPut]
        [Route("{id}")]
        public ActionResult UpdateUser(int id, [FromBody]UserDto dto)
        {
            var u = UserList.SingleOrDefault(x => x.Id == id);
            if(u == null)
            {
                return NotFound();
            }

            u.Name = dto.Name;
            u.Surname = dto.Surname;
            u.Email = dto.Email;
            u.Birthdate = dto.Birthdate;

            return NoContent();
        }


        [HttpDelete]
        [Route("{id}")]
        public ActionResult DeleteUserById(int id)
        {
            var u = UserList.SingleOrDefault(x => x.Id == id);
            if (u == null)
            {
                return NotFound();
            }
            UserList.Remove(u);

            return NoContent();
        }
    }
}
