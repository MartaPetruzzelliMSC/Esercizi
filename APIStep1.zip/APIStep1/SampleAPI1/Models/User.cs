﻿namespace SampleAPI1.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public DateOnly Birthdate { get; set; }
    }
}
